/*

BOTNAME: OTP SPAM BOT

Developer: Xvlovers
Tools for make this bot: Deepseek

©dont delete this credit!!
thanks to :
- xvlovers (developer)
- deepseek (helper for fix error code)
- all member xvlovers WhatsApp chanel

whatsapp channel: https://whatsapp.com/channel/0029VbCKJpb6LwHpbtC1mb3E




*/
/**
 * Bot initialization & polling handler
 */
const TelegramBot = require('node-telegram-bot-api');
const fs = require('fs');
const CONFIG = require('./config');
const { COMMANDS } = require('./commands');
const logger = require('./utils/logger');

/**
 * Inisialisasi bot dan setup polling
 */
function initBot() {
  if (!CONFIG.BOT_TOKEN) {
    logger.error('BOT_TOKEN tidak ditemukan! Pastikan file .env sudah diisi.');
    process.exit(1);
  }

  const bot = new TelegramBot(CONFIG.BOT_TOKEN, CONFIG.POLLING_OPTIONS);

  // Handle semua pesan
  bot.on('message', async (msg) => {
    try {
      // Abaikan pesan tanpa text
      if (!msg.text) return;

      const text = msg.text.trim();
      const command = text.split(' ')[0].split('@')[0]; // Handle command dengan mention bot

      // Cek apakah command valid
      if (!COMMANDS[command]) return;

      const chatId = msg.chat.id;
      const userId = msg.from.id;

      // Command /start bisa diakses tanpa owner check jika config belum ada
      if (command === '/start') {
        if (fs.existsSync(CONFIG.CONFIG_FILE)) {
          const data = JSON.parse(fs.readFileSync(CONFIG.CONFIG_FILE, 'utf8'));
          if (userId !== data.ownerId) {
            return bot.sendMessage(chatId, '⚠️ Bot ini hanya bisa digunakan oleh owner.');
          }
        }
        return COMMANDS[command](msg, bot);
      }

      // Cek kepemilikan untuk command lain
      if (!fs.existsSync(CONFIG.CONFIG_FILE)) {
        return bot.sendMessage(chatId, '⚠️ Bot belum di-setup. Gunakan /start terlebih dahulu.');
      }

      const ownerData = JSON.parse(fs.readFileSync(CONFIG.CONFIG_FILE, 'utf8'));

      if (userId !== ownerData.ownerId) {
        return bot.sendMessage(chatId, '⚠️ Anda bukan owner bot ini.');
      }

      // Jalankan command
      await COMMANDS[command](msg, bot);
    } catch (err) {
      logger.error(`Bot error: ${err.message}`);
    }
  });

  // Handle polling errors
  bot.on('polling_error', (err) => {
    if (err.code === 'EFATAL') {
      logger.error('Fatal polling error, restarting...');
      process.exit(1);
    }
    // Minimalisasi log polling
  });

  logger.success('Bot initialized successfully');
  return bot;
}

module.exports = { initBot };