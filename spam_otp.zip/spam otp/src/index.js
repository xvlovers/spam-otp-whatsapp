/*

BOTNAME: OTP SPAM BOT

Developer: Xvlovers
Tools for make this bot: Deepseek

©dont delete this credit!!
thanks to :
- xvlovers (developer)
- deepseek (helper for fix error code)
- all member xvlovers WhatsApp chanel

whatsapp channel: https://whatsapp.com/channel/0029VbCKJpb6LwHpbtC1mb3E




*/

/**
 * Entry point - menjalankan bot
 */
const fs = require('fs');
const CONFIG = require('./config');
const { initBot } = require('./bot');
const { showBanner } = require('./console');
const logger = require('./utils/logger');

/**
 * Main function
 */
async function main() {
  // Pastikan folder data ada
  if (!fs.existsSync(CONFIG.DATA_DIR)) {
    fs.mkdirSync(CONFIG.DATA_DIR, { recursive: true });
    logger.info('Data directory created');
  }

  // Baca owner ID jika sudah ada
  let ownerId = null;
  if (fs.existsSync(CONFIG.CONFIG_FILE)) {
    try {
      const data = JSON.parse(fs.readFileSync(CONFIG.CONFIG_FILE, 'utf8'));
      ownerId = data.ownerId;
    } catch (err) {
      logger.warn('Failed to read config.json');
    }
  }

  // Tampilkan banner
  showBanner(ownerId);

  // Inisialisasi bot
  const bot = initBot();

  logger.info(`Bot started successfully`);
  logger.info(`Owner: ${ownerId || 'Not set - waiting for /start'}`);
}

// Jalankan
main().catch((err) => {
  logger.error(`Fatal error: ${err.message}`);
  process.exit(1);
});