/**
 * HTTP request handler dengan retry, delay, dan random headers
 */
const axios = require('axios');
const { randomUa, randomIp, rand, sleep } = require('./helpers');

const CONFIG = {
  retries: 2,
  timeout: 45000,
  delayMin: 3000,
  delayMax: 5000
};

/**
 * Kirim HTTP POST request ke endpoint OTP dengan retry mechanism
 * @param {Object} endpoint - Object endpoint { name, url, json, headers }
 * @returns {Promise<Object>} - { success, name, status, message }
 */
async function sendRequest(endpoint) {
  const headers = {
    'Content-Type': 'application/json',
    'User-Agent': randomUa(),
    'X-Forwarded-For': randomIp(),
    'X-Real-IP': randomIp(),
    'Accept': 'application/json, text/plain, */*',
    'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8',
    'Connection': 'keep-alive',
    ...(endpoint.headers || {})
  };

  const url = endpoint.url;
  const isFastwork = url.toLowerCase().includes('fastwork');
  const delay = isFastwork ? rand(30000, 45000) : rand(CONFIG.delayMin, CONFIG.delayMax);

  await sleep(delay);

  for (let attempt = 0; attempt <= CONFIG.retries; attempt++) {
    try {
      const resp = await axios.post(url, endpoint.json, {
        headers,
        timeout: CONFIG.timeout
      });

      const status = resp.status;
      if ([200, 201, 202, 204].includes(status)) {
        return { success: true, name: endpoint.name, status };
      }

      if (status === 429) {
        let retryAfter = 30;
        try {
          if (resp.data && resp.data.retry_after) {
            retryAfter = parseInt(resp.data.retry_after);
          }
        } catch (e) {
          // ignore parse error
        }
        await sleep(retryAfter * 1000);
        continue;
      }

      if (attempt < CONFIG.retries) {
        await sleep(rand(5000, 8000));
        continue;
      }

      return {
        success: false,
        name: endpoint.name,
        status,
        message: resp.data?.message || 'Gagal'
      };
    } catch (err) {
      if (attempt < CONFIG.retries) {
        await sleep(rand(5000, 8000));
        continue;
      }
      return {
        success: false,
        name: endpoint.name,
        status: err.response?.status || 0,
        message: err.message
      };
    }
  }

  return { success: false, name: endpoint.name, message: 'Max retries' };
}

module.exports = { sendRequest };