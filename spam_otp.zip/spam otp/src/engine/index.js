/**
 * Engine exports - semua modul engine
 */
const { getEndpoints } = require('./endpoints');
const { sendRequest } = require('./request');
const { spamOtp } = require('./spam');
const { randomIp, randomUa, randomEmail, rand, sleep } = require('./helpers');

module.exports = {
  getEndpoints,
  sendRequest,
  spamOtp,
  randomIp,
  randomUa,
  randomEmail,
  rand,
  sleep
};