/*

BOTNAME: OTP SPAM BOT

Developer: Xvlovers
Tools for make this bot: Deepseek

©dont delete this credit!!
thanks to :
- xvlovers (developer)
- deepseek (helper for fix error code)
- all member xvlovers WhatsApp chanel

whatsapp channel: https://whatsapp.com/channel/0029VbCKJpb6LwHpbtC1mb3E




*/
/**
 * Engine helpers - utility functions untuk spam engine
 */

const USER_AGENTS = [
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36',
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36',
  'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36',
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/120.0',
  'Mozilla/5.0 (iPhone; CPU iPhone OS 17_2 like Mac OS X) Safari/604.1',
  'Mozilla/5.0 (Linux; Android 14; SM-S921B) Chrome/120.0.0.0 Mobile Safari/537.36'
];

/**
 * Generate random IP address
 * @returns {string}
 */
function randomIp() {
  return `${rand(1, 255)}.${rand(1, 255)}.${rand(1, 255)}.${rand(1, 255)}`;
}

/**
 * Get random User-Agent dari list
 * @returns {string}
 */
function randomUa() {
  return USER_AGENTS[Math.floor(Math.random() * USER_AGENTS.length)];
}

/**
 * Generate random email address
 * @returns {string}
 */
function randomEmail() {
  const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';
  for (let i = 0; i < 10; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result + '@bwmyga.com';
}

/**
 * Generate random number dalam range
 * @param {number} min
 * @param {number} max
 * @returns {number}
 */
function rand(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

/**
 * Delay async
 * @param {number} ms - Milliseconds
 * @returns {Promise}
 */
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

module.exports = { randomIp, randomUa, randomEmail, rand, sleep };