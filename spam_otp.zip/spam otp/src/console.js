/*

BOTNAME: OTP SPAM BOT

Developer: Xvlovers
Tools for make this bot: Deepseek

©dont delete this credit!!
thanks to :
- xvlovers (developer)
- deepseek (helper for fix error code)
- all member xvlovers WhatsApp chanel

whatsapp channel: https://whatsapp.com/channel/0029VbCKJpb6LwHpbtC1mb3E




*/
/**
 * Console utilities - banner, logging, formatting (tanpa boxen)
 */
const chalk = require('chalk');
const figlet = require('figlet');
const gradient = require('gradient-string');
const CONFIG = require('./config');

/**
 * Menampilkan ASCII banner dan info bot saat startup
 * @param {number} ownerId - ID owner Telegram
 */
function showBanner(ownerId) {
  console.clear();

  const ascii = figlet.textSync('OTP SPAM BOT', {
    font: 'Standard',
    horizontalLayout: 'default',
    verticalLayout: 'default'
  });

  console.log(gradient.pastel.multiline(ascii));

  const now = new Date();
  const dateStr = now.toLocaleDateString('en-GB', {
    day: '2-digit',
    month: 'short',
    year: 'numeric'
  });
  const timeStr = now.toLocaleTimeString('en-GB', { hour12: false });

  const line = chalk.cyan('╔══════════════════════════════════════════╗');
  const mid1 = `${chalk.cyan('║')}         ${chalk.green.bold('OTP SPAM BOT - ACTIVE')}           ${chalk.cyan('║')}`;
  const mid2 = `${chalk.cyan('║')}  ${chalk.white('Owner ID')} : ${chalk.yellow(String(ownerId || 'Not set').padEnd(27))}${chalk.cyan('║')}`;
  const mid3 = `${chalk.cyan('║')}  ${chalk.white('Version')}  : ${chalk.yellow(CONFIG.VERSION.padEnd(27))}${chalk.cyan('║')}`;
  const mid4 = `${chalk.cyan('║')}  ${chalk.white('Started')}  : ${chalk.yellow(`${dateStr}, ${timeStr}`.padEnd(27))}${chalk.cyan('║')}`;
  const bottom = chalk.cyan('╚══════════════════════════════════════════╝');

  console.log(line);
  console.log(mid1);
  console.log(mid2);
  console.log(mid3);
  console.log(mid4);
  console.log(bottom);
}

/**
 * Log spam execution start
 * @param {string} phone - Nomor target
 */
function logSpamStart(phone) {
  const time = chalk.gray(`[${new Date().toLocaleTimeString('en-GB', { hour12: false })}]`);
  console.log(`\n${time} ${chalk.yellow('📱 Target:')} ${chalk.cyan(phone)}`);
}

/**
 * Log single endpoint result
 * @param {string} name - Nama endpoint
 * @param {boolean} success - Status keberhasilan
 * @param {number} status - HTTP status code
 */
function logEndpointResult(name, success, status) {
  const time = chalk.gray(`[${new Date().toLocaleTimeString('en-GB', { hour12: false })}]`);
  const icon = success ? chalk.green('✅') : chalk.red('❌');
  const extra = !success ? chalk.red(` (${status || 'error'})`) : '';
  console.log(`${time} ${icon} ${chalk.white(name)}${extra}`);
}

/**
 * Log spam execution summary
 * @param {number} success - Jumlah sukses
 * @param {number} total - Total endpoint
 * @param {number} elapsed - Waktu tempuh dalam detik
 */
function logSpamSummary(success, total, elapsed) {
  const failed = total - success;
  console.log(chalk.gray('─'.repeat(50)));
  console.log(`  ${chalk.green(`✅ Sukses: ${success}/${total}`)}  |  ${chalk.red(`❌ Gagal: ${failed}/${total}`)}  |  ${chalk.yellow(`⏱️ ${elapsed.toFixed(1)}s`)}`);
  console.log(chalk.gray('─'.repeat(50)));
}

module.exports = { showBanner, logSpamStart, logEndpointResult, logSpamSummary };