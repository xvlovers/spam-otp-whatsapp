/*

BOTNAME: OTP SPAM BOT

Developer: Xvlovers
Tools for make this bot: Deepseek

©dont delete this credit!!
thanks to :
- xvlovers (developer)
- deepseek (helper for fix error code)
- all member xvlovers WhatsApp chanel

whatsapp channel: https://whatsapp.com/channel/0029VbCKJpb6LwHpbtC1mb3E




*/
const path = require('path');
require('dotenv').config();

const CONFIG = {
  BOT_TOKEN: process.env.BOT_TOKEN || '',
  DATA_DIR: path.join(__dirname, '..', 'data'),
  CONFIG_FILE: path.join(__dirname, '..', 'data', 'config.json'),
  VERSION: '1.0.0',
  POLLING_OPTIONS: { polling: true }
};

module.exports = CONFIG;