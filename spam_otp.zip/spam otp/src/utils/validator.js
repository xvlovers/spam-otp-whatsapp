/**
 * Phone number validation utilities
 */

/**
 * Validasi format nomor telepon Indonesia
 * @param {string} phone - Nomor telepon yang akan divalidasi
 * @returns {boolean} - True jika valid
 */
function isValidPhone(phone) {
  if (!phone) return false;
  const cleaned = String(phone).replace(/\D/g, '');
  return /^62[0-9]{10,13}$/.test(cleaned);
}

/**
 * Normalisasi nomor telepon ke format 62xxx
 * @param {string} phone - Nomor telepon input
 * @returns {string} - Nomor telepon ternormalisasi
 */
function normalizePhone(phone) {
  let p = String(phone).replace(/\D/g, '');
  if (p.startsWith('0')) {
    p = '62' + p.substring(1);
  }
  if (!p.startsWith('62')) {
    p = '62' + p;
  }
  return p;
}

module.exports = { isValidPhone, normalizePhone };