/**
 * Console logger utility dengan timestamp
 */
const chalk = require('chalk');

const logger = {
  /**
   * Log info message
   * @param {string} message - Pesan yang akan ditampilkan
   */
  info(message) {
    const time = new Date().toLocaleTimeString('en-GB', { hour12: false });
    console.log(`${chalk.gray(`[${time}]`)} ${chalk.blue('[INFO]')} ${message}`);
  },

  /**
   * Log success message
   * @param {string} message - Pesan yang akan ditampilkan
   */
  success(message) {
    const time = new Date().toLocaleTimeString('en-GB', { hour12: false });
    console.log(`${chalk.gray(`[${time}]`)} ${chalk.green('[OK]')} ${message}`);
  },

  /**
   * Log error message
   * @param {string} message - Pesan yang akan ditampilkan
   */
  error(message) {
    const time = new Date().toLocaleTimeString('en-GB', { hour12: false });
    console.log(`${chalk.gray(`[${time}]`)} ${chalk.red('[ERROR]')} ${message}`);
  },

  /**
   * Log warning message
   * @param {string} message - Pesan yang akan ditampilkan
   */
  warn(message) {
    const time = new Date().toLocaleTimeString('en-GB', { hour12: false });
    console.log(`${chalk.gray(`[${time}]`)} ${chalk.yellow('[WARN]')} ${message}`);
  }
};

module.exports = logger;