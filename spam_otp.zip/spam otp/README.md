# OTP Spam Bot

Telegram bot untuk mengirim OTP spam ke nomor target.

## Instalasi

1. Clone repository
2. Install dependencies: `npm install`
3. Copy `.env.example` ke `.env` dan isi `BOT_TOKEN`
4. Jalankan: `npm start`

## Command

- `/start` - Setup owner (hanya sekali)
- `/spam <nomor>` - Kirim OTP spam
- `/status` - Info bot
- `/owner` - Info owner
- `/help` - Daftar command

#NODE MINIMAL 20+